"""module classes: module yang berisi class-class yang berguna dalam program
class yang ada pada module ini utamanya adalah class yang digunakan untuk
menampilkan GUI dalam program
"""

from tkinter import *

class GUI():
    """Class GUI: class yang merepresentasikan GUI dasar dari aplikasi ini"""
    
    def __init__(self,size=None):
        self.bgcolor = "#e0e0e0"
        self.window = Tk()
        self.window.title("Program GUI")
        self.window["bg"] = self.bgcolor
        self.window.resizable(width=False, height=False)
        self.__setMenu()
        self.setGUI()
        self.window.geometry(size)
        self.window.mainloop()

    def setGUI(self):
        """method utama untuk mengatur tata letak window"""
        pass
        
    def __setMenu(self):
        """method untuk mengatur tata letak menu"""
        self.menubar = Menu(self.window)
        self.window["menu"] = self.menubar
        self.mainMenu = Menu(self.menubar, tearoff = 0)
        self.menubar.add_cascade(label="Menu", menu = self.mainMenu)
        self.mainMenu.add_command(label = "Quit", command = self.__quit)

    def __quit(self):
        """method handler ketika item dari menu ditekan"""
        self.window.destroy()


class IdentityForm(GUI):
    """Class Game: class yang merepresentasikan GUI untuk memasukkan nama"""
    
    def __init__(self):
        super(IdentityForm,self).__init__()        

    def setGUI(self):
        """method utama untuk mengatur tata letak window"""
        self.window.title("Mulai permainan")
        frame1 = self.__setFrame1()
        button = Button(self.window, text="submit", command=self.__submitName)
        frame1.grid(row=1, column=1, padx=15, pady=3)
        button.grid(row=2, column=1, stick=E, padx=15)
        
        
    def __setFrame1(self):
        """method untuk meletakkan widget GUI untuk memasukkan nama"""
        frame = Frame(self.window, bg=self.bgcolor)
        label = Label(frame, text="Isi dengan nama kalian: ", bg=self.bgcolor)
        self.varName = StringVar()
        entryName = Entry(frame, textvariable=self.varName)
        label.grid(row=1,column=1)
        entryName.grid(row=1,column=2,padx=5)
        return frame

    def __submitName(self):
        """method handler dari button submit"""
        self.name = self.varName.get()
        self.window.destroy()

    def getName(self):
        """method untuk mengambil nama yang dimasukkan"""
        return self.name

class Game(GUI):
    """Class Game: class yang merepresentasikan GUI pada game"""
    
    def __init__(self,playerName):
        self.__playerName = playerName
        self.rightAnswer = "Jawaban Anda Benar!"
        self.wrongAnswer = "Jawaban Anda Salah!"
        super(Game,self).__init__("550x490")

    def getPlayerName():
        """method untuk mengambil nama pemain"""
        return self.__playerName
    
    def setGUI(self):
        """method utama untuk mengatur tata letak window"""
        self.window.title("Game Tebak Lagu")
        informationPane = self.__setInformationPane()
        informationPane.grid(row=1, column=1, stick=W)
        answerField = self.__setAnswerField()
        answerField.grid(row=2, column=1, rowspan=2, columnspan=2, stick=W)
        answerInformation = self.__setAnswerInformation()
        answerInformation.grid(row=1, column=3, columnspan=4,stick=E,padx=10)
        textInformation = self.__setTextPane()
        textInformation.grid(row=4,column=1, columnspan=6, pady=10)
    
    def __setInformationPane(self):
        """method untuk meletakkan widget yang berisi informasi pemain"""
        frame = Frame(self.window, bg= self.bgcolor)
        label1 = Label(frame, text="Nama Pemain:", bg= self.bgcolor)
        label1.grid(row=1,column=1)
        label2 = Label(frame, text=self.__playerName, bg= self.bgcolor)
        label2.grid(row=1, column=2)
        return frame

    def __setAnswerField(self):
        """method untuk meletakkan widget untuk pemasukan jawaban game"""
        frame = Frame(self.window, bg=self.bgcolor)
        label1 = Label(frame, text="Jawaban:", bg= self.bgcolor)
        label1.grid(row=1,column=1)
        entry = Entry(frame, width=50)
        entry.grid(row=1, column=2)
        button = Button(frame, text="Submit", command=self.__submissionResponse)
        button.grid(row=2, column=2, stick = E, padx=5)
        return frame

    def __setAnswerInformation(self):
        # tampilkan informasi dari tebakan lirik di sini
        frame = Frame(self.window, bg= self.bgcolor)
        self.answerLabel = Label(frame, bg= self.bgcolor)
        self.answerLabel.grid(row=1,column=1)
        return frame

    def __setTextPane(self):
        # tampilkan lirik yang akan ditebak di sini
        frame = Frame(self.window, bg= self.bgcolor)
        self.text = Text(frame,width=68)
        self.text.pack()
        return frame

    def __submissionResponse(self):
        # lakukan pengecekan jawaban lirik di sini
        self.answerLabel["text"] = self.rightAnswer
    
        
        
