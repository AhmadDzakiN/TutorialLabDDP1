"""module mainprogram: module utama untuk menjalankan program"""

from classes import *

# tampilkan GUI untuk mengambil identitas pemain
identity = IdentityForm()
# mainkan Game
game = Game(identity.getName())
